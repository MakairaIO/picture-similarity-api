<?php
namespace App\Controller;

use App\Entity\PictureSimilarity;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class PictureSimilarityController extends Controller
{
    /** @return Response */
    public function find($shop, $productId)
    {
        $repository = $this->getDoctrine()->getRepository(PictureSimilarity::class);
        $similar = $repository->findBy(['productId' => $productId, 'shop' => $shop], ['updatedAt' => 'DESC']);
        if (!$similar) {
            throw $this->createNotFoundException('No Similary Products found.');
        }

        return $this->json($similar[0]);
    }
}
